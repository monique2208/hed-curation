Run the run.py script with following arguments:

		-d bids_dir 
		-t task_name 
		-o operations_json_path

Example:

		python .\enhance\run.py -d D:\Gebruikers\Monique\ds002790sm_adaptedcolumns -t task_name -o enhance_stopsignal.json

